-- DB Final Project Skeleton
-- Student Name: Sim Jae Yeong
-- Student ID: 2326032

-- 1. CREATE TABLE

CREATE TABLE class_code (
	code INT PRIMARY KEY,
	class VARCHAR(10),
	basis VARCHAR(20)
);

CREATE TABLE task_code (
	code INT PRIMARY KEY,
	task VARCHAR(30)
);

-- TODO: customer
CREATE TABLE customer (
	cus_id VARCHAR(15) PRIMARY KEY,
	name VARCHAR(20) NOT NULL,
	cell CHAR(13) NOT NULL UNIQUE,
	addr VARCHAR(100),
	c_code INT DEFAULT 3,
	FOREIGN KEY (c_code) REFERENCES class_code(code)
);

-- TODO: staff
CREATE TABLE staff (
	staff_id INT PRIMARY KEY,
	name VARCHAR(20) NOT NULL,
	birthday INT NOT NULL,
	tel CHAR(12),
	salary INT,
	t_code INT NOT NULL,
	hire_date CHAR(8) NOT NULL,
	FOREIGN KEY (t_code) REFERENCES task_code(code)
);

-- TODO: tour
CREATE TABLE tour (
	tour_num CHAR(8) PRIMARY KEY,
	departure VARCHAR(50) NOT NULL,
	arrival VARCHAR(50) NOT NULL,
	program VARCHAR(100),
	start_dt DATE NOT NULL,
	end_dt DATE NOT NULL,
	min_num INT,
	max_num INT,
	expense INT NOT NULL,
	deposit INT,
	dept_yn CHAR(1) DEFAULT 'N',
	staff_id INT,
	FOREIGN KEY (staff_id) REFERENCES staff(staff_id)
);

-- TODO: reserve
CREATE TABLE reserve (
	cus_id VARCHAR(15),
	tour_num CHAR(8),
	res_date CHAR(8) DEFAULT CURRENT_DATE,
	dep_yn CHAR(1) DEFAULT 'N',
	exp_yn CHAR(1) DEFAULT 'N',
	PRIMARY KEY (cus_id, tour_num),
	FOREIGN KEY (cus_id) REFERENCES customer(cus_id),
	FOREIGN KEY (tour_num) REFERENCES tour(tour_num)
);

-- 2. INSERT DATA
-- 데이터를 검증 및 수정할 때, ChatGPT를 사용했습니다. 
-- 전체 데이터는 수업 자료를 바탕으로 제가 직접 작성했습니다. 
-- TODO: Insert at least 5 rows into each table

INSERT INTO class_code (code, class, basis) VALUES
(1, '최우수', '누적 결제 300만원 이상'),
(2, '우수', '누적 결제 100만원 이상'),
(3, '일반', '기본 등급');

INSERT INTO task_code (code, task) VALUES
(1, '여행상품관리'),
(2, '예약관리'),
(3, '관광버스배차관리'),
(4, '직원관리'),
(5, '고객관리');

INSERT INTO customer (cus_id, name, cell, addr, c_code) VALUES
('001', '김제논', '010-1111-1111', '서울시 강남구', 1),
('002', '김아델', '010-2222-2222', '서울시 송파구', 2),
('003', '김보마', '010-3333-3333', '경기도 성남시', 3),
('004', '김불독', '010-4444-4444', '인천시 연수구', 2),
('005', '김키네', '010-5555-5555', '대전시 유성구', 3);

INSERT INTO staff (staff_id, name, birthday, tel, salary, t_code, hire_date) VALUES
(10001, '김칼리', 990101, '02-1111-1111', 3200000, 1, '20230110'),
(10002, '김데슬', 990102, '02-2222-2222', 3000000, 2, '20230215'),
(10003, '김데벤', 080101, '02-3333-3333', 3400000, 3, '20220801'),
(10004, '김리움', 100505, '02-4444-4444', 3100000, 4, '20240105'),
(10005, '김썬콜', 890808, '02-5555-5555', 2950000, 5, '20240320');

INSERT INTO tour (tour_num, departure, arrival, program, start_dt, end_dt, min_num, max_num, expense, deposit, dept_yn, staff_id) VALUES
('00000001', '서울', '부산', 'https://tour.com/busan', '2026-07-01', '2026-07-03', 10, 40, 350000, 50000, 'N', 10001),
('00000002', '서울', '강릉', 'https://tour.com/gangneung', '2026-07-10', '2026-07-11', 8, 30, 180000, 30000, 'N', 10002),
('00000003', '대전', '경주', 'https://tour.com/gyeongju', '2026-07-15', '2026-07-17', 12, 35, 290000, 40000, 'Y', 10001),
('00000004', '부산', '전주', 'https://tour.com/jeonju', '2026-08-01', '2026-08-02', 15, 45, 210000, 30000, 'N', 10003),
('00000005', '서울', '제주', 'https://tour.com/jeju', '2026-08-20', '2026-08-22', 20, 40, 480000, 70000, 'Y', 10002);

INSERT INTO driver (driver_id, name, birthday, cell, pay, cont_date, cont_term) VALUES
(20001, '김기사', '780101', '010-1234-1234', 16000, '20260101', '00000012'),
(20002, '이기사', '790305', '010-2345-2345', 15500, '20260201', '00000003'),
(20003, '박기사', '820711', '010-3456-3456', 15000, '20260301', '00000006'),
(20004, '최기사', '850912', '010-4567-4567', 16500, '20260115', '00000009'),
(20005, '강기사', '830121', '010-5678-5678', 15800, '20260401', '00000012');

INSERT INTO tour_bus (bus_id, seat, del_yesr) VALUES
(1, 28, 2018),
(2, 32, 2020),
(3, 45, 2019),
(4, 40, 2021),
(5, 25, 2017);

INSERT INTO reserve (cus_id, tour_num, res_date, dep_yn, exp_yn) VALUES
('001', '00000001', '20260601', 'Y', 'N'),
('002', '00000001', '20260602', 'N', 'N'),
('003', '00000002', '20260605', 'Y', 'N'),
('004', '00000003', '20260608', 'Y', 'Y'),
('005', '00000005', '20260610', 'N', 'N');

INSERT INTO assign_driver (tour_num, driver_id, work_hour) VALUES
('00000001', 20001, 16),
('00000002', 20002, 10),
('00000003', 20003, 18),
('00000004', 20004, 12),
('00000005', 20005, 20);

INSERT INTO assign_bus (tour_num, bus_id) VALUES
('00000001', 1),
('00000002', 2),
('00000003', 3),
('00000004', 4),
('00000005', 5);

-- 3. INDEX

-- TODO: CREATE INDEX
CREATE INDEX tour_arrival_idx ON tour(arrival ASC);

-- 기본값이 ASC 이므로 생략 가능
CREATE INDEX driver_name_idx ON driver(name);

-- 4. TEST QUERIES
-- 데이터를 검증 및 수정할 때, ChatGPT를 사용했습니다. 
-- 전체 데이터는 수업 자료를 바탕으로 제가 직접 작성했습니다. 

-- Customer Grade Search
SELECT c.name, cc.class FROM customer c
JOIN class_code cc ON c.c_code = cc.code
WHERE c.cus_id = '001';

-- Employee Task Search
SELECT s.name, tc.task FROM staff s
JOIN task_code tc ON s.t_code = tc.code
WHERE s.staff_id = 10002;

-- Tour Reservation Search
SELECT c.name, r.res_date, r.dep_yn FROM reserve r
JOIN customer c ON r.cus_id = c.cus_id
WHERE r.tour_num = '00000001';

-- Assigned Driver Search
SELECT t.departure, d.name, d.cell FROM assign_driver ad
JOIN tour t ON ad.tour_num = t.tour_num
JOIN driver d ON ad.driver_id = d.driver_id
WHERE t.tour_num = '00000001';

-- INSERT example
INSERT INTO customer (cus_id, name, cell, addr, c_code) VALUES 
('006', '김카데나', '010-6666-6666', '광주시 북구', 3);

TABLE customer;

-- UPDATE example
UPDATE staff SET salary = salary + 200000
WHERE staff_id = 10002;

TABLE staff;

-- DELETE example
DELETE FROM reserve WHERE cus_id = '005' AND tour_num = '00000005';

TABLE reserve;

-- 5. BONUS TABLES (Optional)

-- driver
CREATE TABLE driver (
	driver_id INT PRIMARY KEY,
	name VARCHAR(20) NOT NULL,
	birthday CHAR(6) NOT NULL,
	cell CHAR(13) NOT NULL,
	pay INT DEFAULT 15000,
	cont_date CHAR(8),
	cont_term CHAR(8)
);

-- tour_bus
CREATE TABLE tour_bus (
	bus_id INT PRIMARY KEY,
	seat INT,
	del_yesr INT
);

-- assign_driver
CREATE TABLE assign_driver (
	tour_num CHAR(8) PRIMARY KEY,
	driver_id INT,
	work_hour INT,
	FOREIGN KEY (tour_num) REFERENCES tour(tour_num),
	FOREIGN KEY (driver_id) REFERENCES driver(driver_id)
);

-- assign_bus
CREATE TABLE assign_bus (
	tour_num CHAR(8) PRIMARY KEY,
	bus_id INT,
	FOREIGN KEY (tour_num) REFERENCES tour(tour_num),
	FOREIGN KEY (bus_id) REFERENCES tour_bus(bus_id)
);

-- DELETE TABLE (ALL)
DROP TABLE assign_bus CASCADE;
DROP TABLE assign_driver CASCADE;
DROP TABLE reserve CASCADE;
DROP TABLE tour CASCADE;
DROP TABLE staff CASCADE;
DROP TABLE customer CASCADE;
DROP TABLE tour_bus CASCADE;
DROP TABLE driver CASCADE;
DROP TABLE class_code CASCADE;
DROP TABLE task_code CASCADE;